<?php
/**
 * @package theProfile
 * @version 1.0
 */
/*
 Plugin Name: theProfile Avatar
 Plugin URI: http://theprofile.co.uk/wordpress
 Description: stores theProfile usernames and returns avatars of those users
 Author: Michael Pontin
 Version: 1.0
 Author URI: http://michaelpontin.com
 */
class theProfile {

	/**
	 * Initalize the plugin by registering the hooks
	 */
	function __construct() {

		// Display theprofile textbox in the comment form
		add_action('comment_form', array(&$this, 'add_theprofile_field'), 9);

		// Save the twitter field
		// priority is very low (50) because we want to let anti-spam plugins have their way first.
		add_filter('comment_post', array(&$this, 'save_theprofile_field'), 50);

		//hook the show gravatar function
		add_filter('get_avatar', array(&$this, 'change_avatar'), 10, 5);

		// Add the javascript
		add_action('template_redirect', array(&$this, 'add_jscript'));


	}
	 /**
     * Add JavaScript
     */
    function add_jscript() 
    {
        // Enqueue the script on single page/post
        if (is_singular()) {
            wp_enqueue_script('tp', plugin_dir_url(__FILE__) . 'theprofile.js', array('jquery'), '0.1', true);
        }
    }
	

	/**
	 * Adds theprofile field to the form
	 */
	function add_theprofile_field() 
	{
		global $wp_scripts;

		if (comments_open()) {
			$cook = esc_attr($_COOKIE["comment_author_theprofile".COOKIEHASH]);
			echo '<p id="theprofile" style="display:block">';
			echo '<label for="theprofile_field">theProfile Username</label>';
			echo '<input type="text" id="theprofile_field" class="textbox" size="30" name="theprofile_field" value="'.$cook.'" />';
			echo '</p>';
		}
	}

	/**
	 * Save the theprofile field as a cookie and as metadata
	 */
	function save_theprofile_field($comment_id) 
	{
		if( isset($_POST['theprofile_field']) && !empty($_POST['theprofile_field']) && $_POST['theprofile_field'] != '') {

			$comment_author_theprofile = $_POST['theprofile_field'];

			setcookie('comment_author_theprofile' . COOKIEHASH, $comment_author_theprofile, time()+60*60*24*30);
			update_metadata('comment', $comment_id, 'comment_author_theprofile', $comment_author_theprofile);
		}
	}
	
	/*
	 * Used to change the image used as their avatar
	 */
	function change_avatar($avatar, $id_or_email, $size, $default, $alt) 
	{
		$user = get_metadata('comment', get_comment_ID(), 'comment_author_theprofile', true);
		$image_url = $this->get_user($user);
		if ($image_url != '') {
			$avatar = "<img alt='theProfileUserImage' src='{$image_url}' class='avatar avatar-{$size} photo avatar-default' height='{$size}' width='{$size}' style='width: {$size}px'/>";
		}
		return $avatar;
	}
		
	/*
	 * Retrieves the user image if they have one
	 * else return the blank image
	 */
	function get_user($user) 
	{
		if(isset($user) && $user != '' && !empty($user))
		{
			$url = "http://theprofile.co.uk/api/{$user}.xml";
			$output = file_get_contents($url);
			$xml = simplexml_load_string($output);
			if(!empty($xml->imageURL)) {
				return $xml->imageURL;
			}
		}
	}
}
add_action( 'init', 'theProfile' ); function theProfile() { global $theProfile; $theProfile = new theProfile(); }
?>
